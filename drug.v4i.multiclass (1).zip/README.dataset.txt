# drug > 2022-10-07 1:38pm
https://universe.roboflow.com/drugdetection/drug-ft4mu

Provided by a Roboflow user
License: CC BY 4.0

